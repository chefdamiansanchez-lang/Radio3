package com.datco.radiosar

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import java.io.File
import java.text.Normalizer
import java.util.concurrent.TimeUnit

data class Station(
    val id: String,
    val name: String,
    val url: String,
    val province: String,
    val cats: List<String>,
    val band: String
)

fun norm(s: String): String =
    Normalizer.normalize(s.lowercase(), Normalizer.Form.NFD).replace(Regex("\\p{Mn}+"), "")

private val PROV_NAMES = listOf(
    "Buenos Aires", "Catamarca", "Chaco", "Chubut", "Córdoba", "Corrientes", "Entre Ríos",
    "Formosa", "Jujuy", "La Pampa", "La Rioja", "Mendoza", "Misiones", "Neuquén", "Río Negro",
    "Salta", "San Juan", "San Luis", "Santa Cruz", "Santa Fe", "Santiago del Estero",
    "Tierra del Fuego", "Tucumán"
)

fun provinceOf(state: String): String {
    val s = norm(state)
    if (s.isBlank()) return "Sin provincia"
    val caba = listOf("caba", "capital federal", "ciudad autonoma", "ciudad de buenos aires", "f.d", "c.a.b.a")
    if (caba.any { s.contains(it) }) return "CABA"
    return PROV_NAMES.firstOrNull { s.contains(norm(it)) } ?: "Sin provincia"
}

private val CAT_RULES = listOf(
    "Folklore" to listOf("folklore", "folclore", "folclor", "folk", "chamame", "zamba"),
    "Pop" to listOf("pop", "hits", "top 40", "top40"),
    "Rock" to listOf("rock", "alternative", "metal", "punk"),
    "Tango" to listOf("tango"),
    "Cumbia" to listOf("cumbia", "cuarteto", "tropical", "bailanta"),
    "Noticias" to listOf("news", "noticias", "talk", "informacion", "periodismo"),
    "Deportes" to listOf("sport", "deporte"),
    "Electrónica" to listOf("electronic", "techno", "house", "dance", "electronica"),
    "Clásica/Jazz" to listOf("classical", "clasica", "jazz"),
    "Latina" to listOf("latin", "romantic", "romantica", "balada")
)

fun categoriesOf(tags: String, name: String): List<String> {
    val t = norm("$tags $name")
    val found = CAT_RULES.filter { (_, keys) -> keys.any { t.contains(it) } }.map { it.first }
    return if (found.isEmpty()) listOf("Variada") else found
}

private val AM_RE = Regex("(?i)\\bAM\\b|\\bAM ?\\d{3,4}|\\d{3,4} ?AM\\b")
private val FM_RE = Regex("(?i)\\bFM\\b|\\b(8[7-9]|9\\d|10[0-8])[.,]\\d\\b")

fun bandOf(name: String): String = when {
    AM_RE.containsMatchIn(name) -> "AM"
    FM_RE.containsMatchIn(name) -> "FM"
    else -> "Online"
}

object Repo {
    private val client = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .build()
    private val hosts = listOf("de1", "nl1", "at1")

    /** Devuelve (emisoras, vinoDeInternet). Si no hay red usa el caché guardado. */
    suspend fun load(ctx: Context): Pair<List<Station>, Boolean> = withContext(Dispatchers.IO) {
        val cache = File(ctx.filesDir, "stations.json")
        for (h in hosts) {
            try {
                val req = Request.Builder()
                    .url("https://$h.api.radio-browser.info/json/stations/search?countrycode=AR&hidebroken=true&order=clickcount&reverse=true&limit=1500")
                    .header("User-Agent", "RadiosArgentinas/1.0")
                    .build()
                client.newCall(req).execute().use { r ->
                    if (r.isSuccessful) {
                        val body = r.body?.string().orEmpty()
                        val list = parse(body)
                        if (list.isNotEmpty()) {
                            cache.writeText(body)
                            return@withContext Pair(list, true)
                        }
                    }
                }
            } catch (e: Exception) {
            }
        }
        if (cache.exists()) {
            try {
                return@withContext Pair(parse(cache.readText()), false)
            } catch (e: Exception) {
            }
        }
        Pair(emptyList(), false)
    }

    private fun parse(body: String): List<Station> {
        val arr = JSONArray(body)
        val out = ArrayList<Station>()
        val seen = HashSet<String>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val name = o.optString("name").trim()
            val url = o.optString("url_resolved").ifBlank { o.optString("url") }.trim()
            if (name.isBlank() || url.isBlank() || !seen.add(url)) continue
            out.add(
                Station(
                    id = o.optString("stationuuid", url),
                    name = name,
                    url = url,
                    province = provinceOf(o.optString("state")),
                    cats = categoriesOf(o.optString("tags"), name),
                    band = bandOf(name)
                )
            )
        }
        return out
    }
}
