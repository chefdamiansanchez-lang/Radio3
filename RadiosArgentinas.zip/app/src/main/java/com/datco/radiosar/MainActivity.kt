package com.datco.radiosar

import android.Manifest
import android.content.ComponentName
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import kotlinx.coroutines.delay

val Celeste = Color(0xFF75AADB)
val CelesteDark = Color(0xFF3F7FB8)
val CelesteSoft = Color(0xFFEAF3FB)

class PlayerState {
    var controller by mutableStateOf<MediaController?>(null)
    var playing by mutableStateOf(false)
    var buffering by mutableStateOf(false)
    var error by mutableStateOf(false)
    var currentId by mutableStateOf<String?>(null)
    var currentName by mutableStateOf("")
    var currentInfo by mutableStateOf("")
}

class MainActivity : ComponentActivity() {
    private val ps = PlayerState()
    private var future: ListenableFuture<MediaController>? = null
    private val notifPerm =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)

        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        val f = MediaController.Builder(this, token).buildAsync()
        future = f
        f.addListener({
            try {
                val c = f.get()
                ps.controller = c
                ps.playing = c.isPlaying
                c.currentMediaItem?.let {
                    ps.currentId = it.mediaId
                    ps.currentName = it.mediaMetadata.title?.toString().orEmpty()
                    ps.currentInfo = it.mediaMetadata.artist?.toString().orEmpty()
                }
                c.addListener(object : Player.Listener {
                    override fun onIsPlayingChanged(isPlaying: Boolean) { ps.playing = isPlaying }
                    override fun onPlaybackStateChanged(state: Int) {
                        ps.buffering = state == Player.STATE_BUFFERING
                        if (state == Player.STATE_READY) ps.error = false
                    }
                    override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                        ps.currentId = mediaItem?.mediaId
                    }
                    override fun onPlayerError(error: PlaybackException) {
                        ps.error = true
                        ps.playing = false
                    }
                })
            } catch (e: Exception) {
            }
        }, ContextCompat.getMainExecutor(this))

        setContent {
            MaterialTheme(
                colorScheme = lightColorScheme(
                    primary = CelesteDark,
                    onPrimary = Color.White,
                    primaryContainer = CelesteSoft,
                    secondary = Celeste,
                    background = Color.White,
                    surface = Color.White
                )
            ) { Root(ps) }
        }
    }

    override fun onDestroy() {
        future?.let { MediaController.releaseFuture(it) }
        super.onDestroy()
    }
}

fun playStation(ps: PlayerState, s: Station) {
    val c = ps.controller ?: return
    if (ps.currentId == s.id) {
        if (ps.error) {
            ps.error = false
            c.prepare(); c.play()
        } else if (c.isPlaying) c.pause() else c.play()
        return
    }
    ps.currentId = s.id
    ps.currentName = s.name
    ps.currentInfo = "${s.band} · ${s.province}"
    ps.error = false
    val item = MediaItem.Builder()
        .setMediaId(s.id)
        .setUri(s.url)
        .setRequestMetadata(MediaItem.RequestMetadata.Builder().setMediaUri(Uri.parse(s.url)).build())
        .setMediaMetadata(
            MediaMetadata.Builder().setTitle(s.name).setArtist("${s.band} · ${s.province}").build()
        )
        .build()
    c.setMediaItem(item)
    c.prepare()
    c.play()
}

@Composable
fun Root(ps: PlayerState) {
    var splash by rememberSaveable { mutableStateOf(true) }
    if (splash) Splash { splash = false } else MainScreen(viewModel<Vm>(), ps)
}

@Composable
fun Splash(onDone: () -> Unit) {
    val a = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        a.animateTo(1f, tween(900))
        delay(1300)
        onDone()
    }
    Box(Modifier.fillMaxSize().background(Color(0xFF1B2028)), contentAlignment = Alignment.Center) {
        Column(Modifier.alpha(a.value), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(
                Modifier.size(96.dp).clip(RoundedCornerShape(22.dp))
                    .background(Brush.linearGradient(listOf(Color(0xFF007BC7), Color(0xFF00D2FF)))),
                contentAlignment = Alignment.Center
            ) { Text("D", fontSize = 54.sp, fontWeight = FontWeight.Bold, color = Color.White) }
            Spacer(Modifier.height(20.dp))
            Text("DATCO", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.Bold, letterSpacing = 10.sp)
            Spacer(Modifier.height(8.dp))
            Text(
                "Desarrollo Avanzado de Tecnologías y Códigos Operativos",
                color = Color(0xFF9FB3C8), fontSize = 12.sp, textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 40.dp)
            )
        }
        Text(
            "Diseño de apps... y algo más",
            color = Color(0xFF9FB3C8), fontSize = 12.sp,
            modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = 40.dp).alpha(a.value)
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(vm: Vm, ps: PlayerState) {
    val all by vm.stations.collectAsState()
    val loading by vm.loading.collectAsState()
    val offline by vm.offline.collectAsState()
    val favs by vm.favs.collectAsState()

    var tab by rememberSaveable { mutableIntStateOf(0) }
    var query by rememberSaveable { mutableStateOf("") }
    var band by rememberSaveable { mutableStateOf("Todas") }
    var prov by rememberSaveable { mutableStateOf("Todas") }
    var cat by rememberSaveable { mutableStateOf("Todas") }
    var menuOpen by remember { mutableStateOf(false) }

    val provinces = remember(all) {
        listOf("Todas") + all.map { it.province }.distinct()
            .sortedWith(compareBy<String>({ it == "Sin provincia" }, { it }))
    }
    val cats = remember(all) { listOf("Todas") + all.flatMap { it.cats }.distinct().sorted() }

    val filtered = remember(all, favs, tab, query, band, prov, cat) {
        val q = norm(query.trim())
        all.filter { s ->
            (tab == 0 || s.id in favs) &&
                (band == "Todas" || s.band == band) &&
                (prov == "Todas" || s.province == prov) &&
                (cat == "Todas" || cat in s.cats) &&
                (q.isEmpty() || norm(s.name).contains(q))
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Radios Argentinas", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = CelesteDark, titleContentColor = Color.White
                )
            )
        },
        bottomBar = { if (ps.currentId != null) MiniPlayer(ps) },
        containerColor = Color.White
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            TabRow(selectedTabIndex = tab, containerColor = Color.White, contentColor = CelesteDark) {
                Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Todas") })
                Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("Favoritas (${favs.size})") })
            }
            OutlinedTextField(
                value = query, onValueChange = { query = it }, singleLine = true,
                placeholder = { Text("Buscar radio") },
                modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp)
            )
            LazyRow(contentPadding = PaddingValues(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(listOf("Todas", "AM", "FM", "Online")) { b ->
                    Chip(b, band == b) { band = b }
                }
            }
            Row(Modifier.padding(horizontal = 12.dp, vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                Box {
                    OutlinedButton(onClick = { menuOpen = true }) { Text("Provincia: $prov") }
                    DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                        provinces.forEach { p ->
                            DropdownMenuItem(text = { Text(p) }, onClick = { prov = p; menuOpen = false })
                        }
                    }
                }
                Spacer(Modifier.width(10.dp))
                Text("${filtered.size} radios", color = Color.Gray, fontSize = 13.sp)
            }
            LazyRow(contentPadding = PaddingValues(horizontal = 12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(cats) { c -> Chip(c, cat == c) { cat = c } }
            }
            Spacer(Modifier.height(6.dp))
            if (offline) Text(
                "Sin conexión: mostrando la última lista guardada",
                color = CelesteDark, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 16.dp)
            )
            when {
                loading -> Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator(color = Celeste) }
                all.isEmpty() -> Column(
                    Modifier.fillMaxSize().padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
                ) {
                    Text("No se pudieron cargar las radios. Revisá tu conexión.", textAlign = TextAlign.Center)
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = { vm.load() }, colors = ButtonDefaults.buttonColors(containerColor = CelesteDark)) {
                        Text("Reintentar")
                    }
                }
                filtered.isEmpty() -> Box(Modifier.fillMaxSize(), Alignment.Center) {
                    Text(if (tab == 1) "Todavía no tenés favoritas ♥" else "Sin resultados", color = Color.Gray)
                }
                else -> LazyColumn(Modifier.fillMaxSize()) {
                    items(filtered, key = { it.id }) { s ->
                        val sel = ps.currentId == s.id
                        StationRow(s, sel, sel && ps.playing, s.id in favs,
                            onClick = { playStation(ps, s) }, onFav = { vm.toggleFav(s.id) })
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Chip(label: String, selected: Boolean, onClick: () -> Unit) {
    FilterChip(
        selected = selected, onClick = onClick, label = { Text(label) },
        colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = Celeste, selectedLabelColor = Color.White
        )
    )
}

@Composable
fun StationRow(
    s: Station, selected: Boolean, playing: Boolean, fav: Boolean,
    onClick: () -> Unit, onFav: () -> Unit
) {
    Column {
        Row(
            Modifier.fillMaxWidth()
                .background(if (selected) CelesteSoft else Color.White)
                .clickable(onClick = onClick)
                .padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier.size(44.dp).clip(CircleShape).background(if (selected) CelesteDark else Celeste),
                contentAlignment = Alignment.Center
            ) {
                val label = if (selected && playing) "▶" else if (s.band == "Online") "WEB" else s.band
                Text(label, color = Color.White, fontWeight = FontWeight.Bold, fontSize = if (label == "WEB") 11.sp else 14.sp)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(s.name, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(
                    "${s.province} · ${s.cats.joinToString(", ")}",
                    fontSize = 12.sp, color = Color.Gray, maxLines = 1, overflow = TextOverflow.Ellipsis
                )
            }
            IconButton(onClick = onFav) {
                Icon(
                    if (fav) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
                    contentDescription = "Favorita",
                    tint = if (fav) Color(0xFFE8506A) else Celeste
                )
            }
        }
        HorizontalDivider(color = CelesteSoft)
    }
}

@Composable
fun MiniPlayer(ps: PlayerState) {
    Surface(color = CelesteDark, shadowElevation = 8.dp) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(ps.currentName, color = Color.White, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                val status = when {
                    ps.error -> "No se pudo reproducir. Tocá ▶ para reintentar"
                    ps.buffering -> "Conectando…"
                    ps.playing -> "En vivo · ${ps.currentInfo}"
                    else -> "Pausada"
                }
                Text(status, color = Color(0xFFDDEBF7), fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            IconButton(onClick = {
                val c = ps.controller
                if (c != null) {
                    if (ps.error) { ps.error = false; c.prepare(); c.play() }
                    else if (c.isPlaying) c.pause() else c.play()
                }
            }) { Text(if (ps.playing) "❚❚" else "▶", color = Color.White, fontSize = 20.sp) }
            IconButton(onClick = {
                ps.controller?.let { it.stop(); it.clearMediaItems() }
                ps.currentId = null
                ps.playing = false
                ps.error = false
            }) { Text("■", color = Color.White, fontSize = 20.sp) }
        }
    }
}
