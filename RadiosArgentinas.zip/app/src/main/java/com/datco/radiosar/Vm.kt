package com.datco.radiosar

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch

class Vm(app: Application) : AndroidViewModel(app) {
    private val prefs = app.getSharedPreferences("radios", 0)

    val stations = MutableStateFlow<List<Station>>(emptyList())
    val loading = MutableStateFlow(true)
    val offline = MutableStateFlow(false)
    val favs = MutableStateFlow(prefs.getStringSet("favs", emptySet())!!.toSet())

    init { load() }

    fun load() {
        viewModelScope.launch {
            loading.value = true
            val (list, online) = Repo.load(getApplication<Application>())
            stations.value = list
            offline.value = !online && list.isNotEmpty()
            loading.value = false
        }
    }

    fun toggleFav(id: String) {
        val n = favs.value.toMutableSet()
        if (!n.add(id)) n.remove(id)
        favs.value = n
        prefs.edit().putStringSet("favs", n).apply()
    }
}
